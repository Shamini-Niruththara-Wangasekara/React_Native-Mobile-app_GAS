import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';
import { AntDesign } from '@expo/vector-icons';

function SplashScreen ({ navigation }){
    return(
        <><View style={{ justifyContent: 'center', alignItems: 'center' }}>
        </View><View style={styles.container}>
        <Text style={styles.text_sn}> SL Gas </Text>
                <View style={styles.header}>
                    <Image
                        source={require('../assets/image1.jpg')}
                        style={styles.logo}
                        resizeMode='stretch' />
                </View>
                <View style={styles.footer}>
                    <Text style={styles.text_sn1}>Stay Connected with SL Gas</Text>
                    <Text style={styles.text_sam}>Signin with the Account</Text>
                    <TouchableOpacity >
                        <Text style={styles.But} onPress={() => navigation.navigate('Login')}>Get Started <AntDesign name="rightcircleo" size={20} color="white" /></Text>
                    </TouchableOpacity>
                </View>
            </View></>
    );
};
export default SplashScreen;

const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#b9e2fa',
    },
    Button:{
        margintop:50,
    },
    header:{
        flex:1,
        justifyContent:"flex-start",
        paddingHorizontal: 20,
        paddingBottom:250
    },
    footer:{
        flex:3,
        backgroundColor:'#fff',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:30,
        paddingVertical:30,
        paddingTop:20,
        paddingBottom:20
    },
    logo:{
        height:150,
        width:150,
        alignContent:'center',
        alignSelf:'center',
        paddingTop:30,
        paddingBottom:30,
        marginTop:70,
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
    },
    text_sn:{
        fontSize:35,
        fontWeight:'bold',
        color:'#011724',
        alignSelf:'center',
        marginTop:20
    },

    text_sn1:{
        fontSize:25,
        fontWeight:'bold',
        color:'#011724'
    },

    text_sam:{
        fontSize:15,
        fontWeight:'bold',
        color:'#011724',
        marginTop:15
    },

    But:{
        backgroundColor:'#0683cc',
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
        borderTopRightRadius:30,
        height:30,
        color:'#fff',
        fontSize:20,
        textAlign:'center',
        width:150,
        marginTop:40,
    }


});