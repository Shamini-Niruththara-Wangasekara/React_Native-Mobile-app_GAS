import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';

function Dashboard({ navigation }) {
    return (
      <View style={styles.container}>
        <View style={{margin:10}}>
        <Button
          title="LP Gas"
          color='#0683cc'
          onPress={() => navigation.navigate('Categories')}
        /></View>
        <View style={{margin:10}}>
        <Button
          title="Live Queue Map"
          color='#0683cc'
          onPress={() => navigation.navigate('Map')}
        /></View>
        <View style={{margin:10}}>
        <Button
          title="Notifications"
          color='#0683cc'
          onPress={() => navigation.navigate('Notifications')}
        /></View>
      </View>
    );
  }

  export default Dashboard;
  const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#b9e2fa',
        justifyContent:'center',
        alignItems:'center',
        
    },

   } );

  