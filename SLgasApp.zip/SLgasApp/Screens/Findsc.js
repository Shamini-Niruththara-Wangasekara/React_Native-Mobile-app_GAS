import React from 'react';
import { Button, Text, View, StyleSheet, Image, SafeAreaView, TextInput } from 'react-native';

function Findsc ({ navigation }) {

    const [text7, onChangeText7] = React.useState(null);
    const [text8, onChangeText8] = React.useState(null);
    const [text9, onChangeText9] = React.useState(null);
    return (
      <View style={styles.container}>
      <SafeAreaView >
        <Text style={styles.textB}>Enter weight of Gas </Text>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText7}
          value={text7}
          placeholder="gas weight"
          keyboardType="default"
          
        />
        <Text style={styles.textB}>Enter your District</Text>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText8}
          value={text8}
          placeholder="district"
          keyboardType="default"
        />
        <Text style={styles.textB}>Enter your City or Town</Text>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText9}
          value={text9}
          placeholder="city/town"
          keyboardType="default"
        />
        <View style={styles.button}>
        <Button onPress={() => navigation.navigate('SearchSuccess')}
          title="Search"
          color='#0683cc'
        /></View>
      </SafeAreaView>
    </View>
      
    );
  };

 export default Findsc ;

  const styles = StyleSheet.create({

    container: {
      flex: 1,
      backgroundColor:'#b9e2fa',
       
    },
    text:{
        color: 'white',
        fontWeight: 'bold',
        fontSize: 40
      },
    textA:{
        fontSize: 40,
        margin:20
      },
    
    input: {
        height: 40,
        margin: 12,
        borderWidth: 1,
        padding: 10,
        backgroundColor:"#adaaa0",
        borderRadius:10,
        
      },
    button: {
        justifyContent: 'center',
        paddingHorizontal: 120,
        paddingVertical: 10, 
      },
    
    text1:{
        textAlign:'center',
        color:'red'
      },
   
    textB:{
        paddingLeft: 15,
        paddingTop: 10,
        color: '#0683cc',
        fontSize: 20,
      },

    searchcon:{
      height:50,
      backgroundColor:"#bfc7bb",
      borderRadius:10,
      flex:1,
      flexDirection:'row',
      alignItems:'center',

    },

});
    