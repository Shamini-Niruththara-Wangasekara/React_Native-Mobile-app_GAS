import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

function Notifications({ navigation }) {
    return (
      <View style={styles.container}>
        <MaterialIcons style={styles.bell} name="notifications" size={30} color="red" />
        <View style={{margin:20}}>
        <Button
          title="    NOTIFICATION  1     "
          color='#3e2bd0'
          onPress={() => navigation.navigate('Map')}/>
        <Button
          title="     NOTIFICATION 2      "
          color='#0c83e6'
          onPress={() => navigation.navigate('Map')} />
       
        <Button
          title="     NOTIFICATION 3      "
          color='#02ddf0'
          onPress={() => navigation.navigate('testscreen')} />
       
        <Button
          title="     NOTIFICATION 4      "
          color='#5fad53'
          onPress={() => navigation.navigate('Map')}/>
        
        <Button 
          title="     NOTIFICATION 5      "
          color='#f57971'
          onPress={() => navigation.navigate('Map')}
        />
        
        </View>
      </View>
      
    );
 }

export default Notifications;
const styles = StyleSheet.create({
  container:{
      flex: 1,
      backgroundColor:'#b9e2fa',
      justifyContent:'center',
      
  },
  bell:{
    alignSelf:'center',


  }

 } );