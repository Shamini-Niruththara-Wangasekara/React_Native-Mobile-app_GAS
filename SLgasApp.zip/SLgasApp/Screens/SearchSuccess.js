import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';
import { AntDesign } from '@expo/vector-icons';

function SearchSuccess ({ navigation }){
    return(
        <View style={styles.container}>
       <View style={{ justifyContent: 'center', alignItems: 'center' }}>
       <AntDesign style={styles.tick}  name="checkcircle" size={24} color="green" />
            <Text style={styles.text_sn}> YOUR REQUEST RECORDED! </Text>
            <Text style={styles.text_sam}> You will receive a Notification soon. </Text>
        </View>
            </View>

    );
};
export default SearchSuccess;

const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#b9e2fa',
    },
    
    header:{
        flex:1,
        justifyContent:"flex-start",
        paddingHorizontal: 20,
        paddingBottom:250
    },
    footer:{
        flex:3,
        backgroundColor:'#fff',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:30,
        paddingVertical:30,
        paddingTop:20,
        paddingBottom:20
    },
 
    text_sn:{
        fontSize:35,
        fontWeight:'bold',
        color:'#0f4232',
        marginTop: 50
    },

    text_sn1:{
        fontSize:25,
        fontWeight:'bold',
        color:'#0f4232'
    },

    text_sam:{
        fontSize:15,
        fontWeight:'bold',
        color:'##05120e',
        marginTop:15
    },

    tick:{
        marginTop:50
    }
  


});

