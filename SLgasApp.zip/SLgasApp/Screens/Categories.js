import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';


function Categories({ navigation }) {
    return (
      <View style={styles.container}>
        <View style={{margin:20}}>
        <Button
          title="Litro"
          color='#0683cc'
        /><Button
          title="5kg"
          color='green'/>
         <Button
          title="12.5kg"
          color='green'/>
         <Button
          title="37.5kg"
          color='green'/></View>  
        <View style={{margin:20}}>
        <Button 
          title="Laughf"
          color='#0683cc'
        /><Button
        title="5kg"
        color='green'/>
        <Button
        title="12.5kg"
        color='green'/>
        <Button
        title="37.5kg"
        color='green'/>
        </View>
        <Text style={styles.But} > </Text>
                    
        </View>
     
    );
  }

  export default Categories;
  const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#b9e2fa',
        justifyContent:'center',
        
    },

   } );


