import React from 'react';
import { Button, Text, View, StyleSheet, Image, SafeAreaView, TextInput } from 'react-native';

function Map({ navigation }) {
  return(
    <><View style={{ justifyContent: 'center', alignItems: 'center' }}>
        
    </View><View style={styles.container}>
            <View style={styles.header}>
                <Image
                    source={require('../assets/map2.png')}
                    style={styles.logo}
                    resizeMode='stretch' />
            </View>
           
        </View></>
);
};
  export default Map;

  const styles = StyleSheet.create({

    container: {
      flex: 1,
      alignItems:'center'  
    },
      Img:{
        width: 400,
        height: 350
      },
      Img1:{
        width: 200,
        height: 300
      },
     
     
    });
    