import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';
import { AntDesign } from '@expo/vector-icons';

function testscreen ({navigate}){
    return (
        <View style={styles.container}>
        <Text style={styles.t}>THIS IS A TEST</Text>
        </View>
    );


};
export default testscreen;
const styles=StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#b9e2fa',
        
    },
    t:{
        marginTop:50
    }
})