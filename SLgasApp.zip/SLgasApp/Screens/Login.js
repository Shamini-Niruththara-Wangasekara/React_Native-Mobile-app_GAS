import React from 'react';
import {View, Text, TouchableOpacity, Button, TextInput, StyleSheet, Image} from 'react-native';
import { AntDesign } from '@expo/vector-icons';

 const Login = ({ navigation }) =>{ 

     const [email, setEmail] = React.useState(''); 
     const [password, setPassword] = React.useState(''); 

     const handleLogin = () =>
     { if(email !== '' && password !== ''){ 
         navigation.navigate('Dashboard');
    }   else{ alert('Please fill all the fields'); 
     } 
} 
return( 
    <View style={styles.container}>
    <View style={styles.header}>
    <Text style={styles.text_sn}>Login</Text> 
    </View>
    <View style={styles.footer}>
    <Text style={styles.text_sam}>Email</Text><AntDesign name="user" size={20} color="black" />
    <TextInput placeholder='Type your Email here' onChangeText={(text)=>setEmail(text)}>
        </TextInput>
    <Text style={styles.text_sam}>Password</Text>      
        <TextInput placeholder='Password' onChangeText={(text)=>setPassword(text)}>
        </TextInput> 
    <Button onPress={handleLogin} title='Login'color='#0683cc'>Login</Button> 
    <Text style={styles.text_sm1}> Dont you have an Account. Signup</Text>
    <Button onPress={()=> navigation.navigate('Signup')} title='Register' color='#0683cc'>SignUp</Button> 
    <Button onPress={()=> navigation.navigate('rest')} title='Reset password' color='#0683cc'>Reset Password</Button> 
    </View> 
    </View >
) 
} 

export default Login;


const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#b9e2fa',
        justifyContent:'center',
        alignItems:'center'
    },
    Button:{
        margintop:50,
    },
    header:{
        flex:1,
        justifyContent:"flex-end",
        paddingHorizontal: 20,
        paddingBottom:50
    },
    footer:{
        flex:3,
        backgroundColor:'#66c7ff',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:90,
        paddingVertical:50,
    },
    text_sn:{
        fontSize:35,
        fontWeight:'bold',
        color:'#011724',
        maxWidth:100
        
    },
    text_sam:{
        fontSize:20,
        fontWeight:'bold',
        color:'#011724',
        marginTop:15
    },
    text_sm1:{
        fontSize:15,
        width:190,
        marginTop:15,
    },
    But:{
        color:'#009287',
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
        borderTopRightRadius:30,
        height:50,
        color:'#fff',
        fontSize:20,
        textAlign:'center',
        width:-300,
        marginTop:10,
        justifyContent:'center'
    }


})