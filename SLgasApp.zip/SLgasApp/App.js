import React from 'react';
import { Button, Text, View, StyleSheet, Image, SafeAreaView, TextInput } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
//import { Provider as PaperProvider } from 'react-native-paper';
//import DrawerNavigator from './DrawerNavigation';

import SplashScreen from "./Screens/SplashScreen";
import Login from "./Screens/Login";
import Signup from "./Screens/Signup";
import Map from "./Screens/Map";
import Dashboard from "./Screens/Dashboard";
import Notifications from './Screens/Notifications';
import SearchSuccess from './Screens/SearchSuccess';
import Findsc from './Screens/Findsc';
import Categories from './Screens/Categories';
import testscreen from './Screens/testscreen';


const HomeStack = createNativeStackNavigator();

function HomeStackScreen() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Welcome" component={SplashScreen} options={{ headerShown: false }} />
      <HomeStack.Screen name="Login" component={Login} options={{ headerShown: false }}/>
      <HomeStack.Screen name="Signup" component={Signup} options={{ headerShown: false }}/>
      <HomeStack.Screen name="Dashboard" component={Dashboard} />
      <HomeStack.Screen name="Categories" component={Categories} />
      <HomeStack.Screen name="Map" component={Map} />
    </HomeStack.Navigator>
  );
}

const SettingsStack = createNativeStackNavigator();

function SettingsStackScreen() {
  return (
    <SettingsStack.Navigator>
      <SettingsStack.Screen name="Notifications" component={Notifications} options={{ headerShown: false }} />
      <SettingsStack.Screen name="test" component={testscreen}/>
      
      
    </SettingsStack.Navigator>
  );
}

const OtherStack = createNativeStackNavigator();
function OtherStackScreen() {
  return (
    <OtherStack.Navigator>
      <OtherStack.Screen name="Search" component={Findsc} options={{ headerShown: false }}/>
      <OtherStack.Screen name="SearchSuccess" component={SearchSuccess}options={{ headerShown: false }} />
    </OtherStack.Navigator>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
      <Tab.Screen name="SLgas" component={HomeStackScreen}  />
      <Tab.Screen name="Search" component={OtherStackScreen} /> 
      <Tab.Screen name="Notification" component={SettingsStackScreen} options={{ tabBarBadge: 3 }}/>
      <Tab.Screen name="Test" component={testscreen} /> 
     </Tab.Navigator>
    </NavigationContainer>
  );
}
//<
    //  <Tab.Screen name="other" component={OtherStackScreen} /> 
//const Stack = createNativeStackNavigator()

//export default function App() {
  //return (
    //<PaperProvider>
    //  <NavigationContainer>
      //  <Stack.Navigator>
        //  <Stack.Screen name="SplashScreen" component={SplashScreen} />
          //<Stack.Screen name="Login" component={Login} />
         // <Stack.Screen name="Signup" component={Signup} />
          //<Stack.Screen name="Map" component={Map} />
          //<Stack.Screen name="Dashboard" component={Dashboard} />
          //<Stack.Screen name="Notifications" component={Notifications} />
          //<Stack.Screen name="SearchSuccess" component={SearchSuccess} />
        //</Stack.Navigator>
       // </NavigationContainer>
    //</PaperProvider>
    
  //);  
//}

//const  SearchSuccessStack = createNativeStackNavigator();

//function SearchSuccessStackScreen() {
  //return (
    //<SearchSuccessStack.Navigator>
      
      //<SearchSuccessStack.Screen name="Login" component={Login} />
      //<SearchSuccessStack.Screen name="Signup" component={Signup} />
    //</SearchSuccessStack.Navigator>
 // );
//}

//const DashboardStack = createNativeStackNavigator();

//function DashboardStackScreen() {
  //return (
    //<DashboardStack.Navigator>
      //<DashboardStack.Screen name="Map" component={Map} />
       
      //<DashboardStack.Screen name="SearchSuccess" component={SearchSuccess} />
    //</DashboardStack.Navigator>
  //);
//}

//const SplashScreenStack = createNativeStackNavigator();

//function SplashScreenStackScreen() {
  //return (
    //<SplashScreenStack.Navigator>
      //<SplashScreenStack.Screen name="Dashboard" component={Dashboard} />
      //<SplashScreenStack.Screen name="Map" component={Map} />
      
    //</SplashScreenStack.Navigator>
  //);
//}

//const Tab = createBottomTabNavigator();

//export default function App() {
  //return (
    //<NavigationContainer>
     // <Tab.Navigator>
       // <Tab.Screen name="SplashScreen" component={SplashScreenStackScreen} />
        //<Tab.Screen name="Dashboard" component={DashboardStackScreen} />
        //<Tab.Screen name="SearchSucces" component={SearchSuccessStackScreen} />
        //</Tab.Navigator>
    //</NavigationContainer>
 // );
//}




//import { StatusBar } from 'expo-status-bar';
//import { StyleSheet, Text, View } from 'react-native';

//export default function App() {
  //return (
    //<View style={styles.container}>
      //<Text>Open up App.js to start working on your app!</Text>
      //<StatusBar style="auto" />
    //</View>
  //);
//}

//const styles = StyleSheet.create({
 // container: {
 //   flex: 1,
   // backgroundColor: '#fff',
    //alignItems: 'center',
    //justifyContent: 'center',
  //},
//});
